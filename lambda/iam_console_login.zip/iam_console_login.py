import json
import boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
  client = boto3.client('iam')
  users  = client.list_users()
  evaluations = []
  config_client = boto3.client('config')

  for user in users['Users']:
    if isPasswordEnabled(client, user):
      evaluations.append(build_evaluation(user['UserName'], 'NON_COMPLIANT', event))
    else:
      evaluations.append(build_evaluation(user['UserName'], 'COMPLIANT', event))

  response = config_client.put_evaluations(
                  Evaluations=evaluations,
                  ResultToken=event['resultToken'])

def isPasswordEnabled(client, user):
  try:
    login_profile = client.get_login_profile(UserName=user['UserName'])
    return True
  except:
    return False

def build_evaluation(resource_id, compliance_type, event):
  eval_cc = {}

  eval_cc['ComplianceResourceType'] = "AWS::S3::Bucket"
  eval_cc['ComplianceResourceId']   = resource_id
  eval_cc['ComplianceType']         = compliance_type
  eval_cc['OrderingTimestamp']      = str(json.loads(event['invokingEvent'])['notificationCreationTime'])

  return eval_cc