import json
import boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    client    = boto3.client("s3")
    resources = client.list_buckets()

    evaluations = []
    config_client = boto3.client('config')

    for resource in resources['Buckets']:
        try:
          client.get_bucket_website(Bucket=resource['Name'])
          evaluations.append(build_evaluation(resource['Name'], "NON_COMPLIANT", event))
        except ClientError as e:
          evaluations.append(build_evaluation(resource['Name'], "COMPLIANT", event))
          continue


    response = config_client.put_evaluations(
                        Evaluations=evaluations,
                        ResultToken=event['resultToken']
                )

    return config_client

def build_evaluation(resource_id, compliance_type, event):
  eval_cc = {}

  eval_cc['ComplianceResourceType'] = "AWS::S3::Bucket"
  eval_cc['ComplianceResourceId']   = resource_id
  eval_cc['ComplianceType']         = compliance_type
  eval_cc['OrderingTimestamp']      = str(json.loads(event['invokingEvent'])['notificationCreationTime'])

  return eval_cc